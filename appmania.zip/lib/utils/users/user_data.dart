String firstName = 'Vishu';
String lastName = 'Patel';

String address = '92 High Street, London';

String imgUrl =
    'https://thumbs.dreamstime.com/b/little-girl-puts-her-hand-to-ear-hear-better-child-listening-something-yellow-background-157882967.jpg ';
