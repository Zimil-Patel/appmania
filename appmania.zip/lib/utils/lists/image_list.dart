List offerImg = [
  'asset/images/OfferBanner/favourite3.png',
  'asset/images/OfferBanner/favourite4.png',
  'asset/images/OfferBanner/favourite2.jpg',
  'asset/images/OfferBanner/favourite.jpg',
];

List brandImg = [
  'asset/images/Brands/apple.png',
  'asset/images/Brands/asus.png',
  'asset/images/Brands/dell.png',
  'asset/images/Brands/onePlus.png',
  'asset/images/Brands/hp.png',
  'asset/images/Brands/acer.png',
];
